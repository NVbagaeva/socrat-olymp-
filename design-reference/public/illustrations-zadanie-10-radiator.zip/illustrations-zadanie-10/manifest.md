# Иллюстрации к заданию №10 (сюжеты прототипов)

Номер файла = номер сюжета в классификации прототипов №10. PNG, прозрачный фон (RGBA).

| № | Файл | Сюжет |
|---|---|---|
| 1 | 01-most.png | Мост (цепь, ванты) |
| 2 | 02-reiting-izdaniya.png | Рейтинг новостного издания |
| 3 | 03-reiting-magazina.png | Рейтинг интернет-магазина |
| 4 | 04-om-predohranitel.png | Закон Ома, предохранитель |
| 5 | 05-eds-nagruzka.png | ЭДС и нагрузка |
| 6 | 06-parallelnoe.png | Параллельное соединение |
| 7 | 07-linza.png | Линза |
| 8 | 08-doppler-teplovoz.png | Тепловоз, эффект Доплера |
| 9 | 09-istochnik-priemnik.png | Источник и приёмник сигнала |
| 10 | 10-batiskaf.png | Батискаф |
| 11 | 11-tormozhenie.png | Торможение автомобиля |
| 12 | 12-motociklist.png | Мотоциклист |
| 13 | 13-lebedka.png | Лебёдка |
| 14 | 14-spros-vyruchka.png | Спрос и выручка |
| 15 | 15-bak-s-kranom.png | Бак с краном |
| 16 | 16-nagrevatel.png | Нагревательный элемент |
| 17 | 17-myach-vverh.png | Мяч вверх |
| 18 | 18-razgon-avtomobilya.png | Разгон автомобиля |
| 19 | 19-gorizont.png | Линия горизонта |
| 20 | 20-zvezda.png | Звезда, Стефан–Больцман |
| 21 | 21-adiabata.png | Адиабатическое сжатие |
| 22 | 22-raspad.png | Радиоактивный распад |
| 23 | 23-kolokol.png | Водолазный колокол |
| 24 | 24-kondensator.png | Конденсатор в телевизоре |
| 26 | 26-myach-pod-uglom.png | Мяч под углом |
| 27 | 27-gruz-na-pruzhine.png | Груз на пружине |
| 28 | 28-soudarenie.png | Неупругое соударение |
| 29 | 29-myachik-nad-stenoj.png | Мячик над стеной |
| 25 | 25-radiator.png | Радиатор отопления |

Дополнительно: extra/04-alt-predohranitel-polnostyu-steklo.png — запасной вариант сюжета 4 (полностью стеклянный), в сборку по умолчанию не берётся.
